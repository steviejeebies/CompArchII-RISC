//
// t3.cpp
//

//
// Compute_Pascal function
//
// Copyright (C) 2020 syed.asad.alam@tcd.ie
//
// 10/12/20 Ubuntu/linux version
// 

//
// Intel64 family 6 model 61 stepping 4 Intel(R) Core(TM) CPU i5-5200U @ 2.5GHz
//
// Case-I
// compute_pascal(30, 20) = 20030010, calls = 40060019 and depth max = 29 (doesn't include main)
// compute_pascal(30, 20) execution time gcc 7.5.0     140.34ms
// Case-II
// compute_pascal(30, 20) = 20030010, calls = 40060019 and depth max = 29 (doesn't include main)
// compute_pascal(30, 20) execution time gcc 7.5.0     143.25ms


#include "time.h"           // clock()
#include <iostream>         // cout
#include <iomanip>          // setprecision

using namespace std;        // cout, endl, ...

#define N       10000      //

#define METHOD  0           // method

int nwindows;               // global variables
int calls;                  //
int depth;                  //
int depthMax;               //
int overflows;              //
int underflows;             //
int row = 30;
int pos = 20;

//
// compute_pascal
//
int compute_pascal(int row, int position) {
  int r;
  if(position == 1)
    {
      r = 1;
    }
  else if(position == row)
    {
      r = 1;
    }
  else
    {
      r = compute_pascal(row-1, position)
	+ compute_pascal(row-1, position-1);
    }
  return r;
}

//
// instrumented compute_pascal version
//

int wused;              // valid register windows

void enter() {
    calls++;
    depth++;
    if (depth > depthMax)
        depthMax = depth;
    if (wused == nwindows) {
        overflows++;
    } else {
        wused++;
    }
}

void exit() {
    depth--;
    if (wused == 2) {   // always need 2 valid windows
        underflows++;
    } else {
        wused--;
    }
}

int compute_pascalX(int row, int position) {
  enter();
  int r;
  if(position == 1)
    {
      r = 1;
    }
  else if(position == row)
    {
      r = 1;
    }
  else
    {
      r = compute_pascalX(row-1, position) +
	compute_pascalX(row-1, position-1);
    }
  exit();
  return r;
}

//
// run
//
void run(int _nwindows) {
    nwindows = _nwindows;           // set number of register windows
    calls = 0;
    depth = depthMax = 0;
    overflows = underflows = 0;
    wused = 2;                      // ALWAYS need two valid windows
    int v = compute_pascalX(row, pos);
    cout << "compute_pascal(" << row << ", " << pos << ") = " << v
	 << ", calls = " << calls << ", max depth = " << depthMax << endl
	 << "nwindows = " << nwindows << ", overflows = "
	 << overflows << ", underflows = " << underflows << endl;
    if (overflows != underflows)
        cout << "ERROR: overflows = " << overflows << " underflows = "
	     << underflows << " (should be equal)" << endl;
    cout << endl;
}

//
// main
//
int main() {

    run(6);
    run(8);
    run(16);

    //
    // Greater accuracy can be obtained by running
    // compute_pascal(row, pos) for a large number of times.
    // The strategy is to execute compute_pascal(row, pos)
    // N times and divide the execution time by N.
    //
    // If the problem occurs that the complier realises
    // that there's no point in executing compute_pascal(row, pos) N times and
    // optimisesaway the loop.
    //
    // To stop this, a volatile variable three is passed to compute_pascal()
    //which makes the compiler generatecode to execute compute_pascal(three, 6)
    //N times.
    //
    int v = 0;
    //volatile int  = row;         // trickery: see below
    cout << "starting..." << endl;
    int t = clock();                // 1ms accuracy
    for (int i = 0; i < N; i++)
      v = compute_pascal(row, pos);
    t = clock() - t;
    cout << "compute_pascal(" << row << ", " << pos << ") = " << v << endl;
    cout << "execution time per call = " << fixed << setprecision(2)
	 << (double)t * 1000.0 / CLOCKS_PER_SEC / N << "ms" << endl;

    return 0;

}
